# More Screenshots
## Laravel Restaurant Reservation 

![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2000-51-51%20our%20story%20LaraRestaurant.png)


![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2000-52-13%20special%20LaraRestaurant.png)


![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2010-45-36%20special%20LaraRestaurant.png)

![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2010-11-07%20step1%20reserv%20LaraRestaurant.png)


![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2010-16-11%20step2%20reserv%20LaraRestaurant.png)


![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2010-08-24%20Menus%20LaraRestaurant.png)


![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2010-08-43%20table%20LaraRestaurant.png)


![Laravel Restaurant Reservation screenshot](./Screenshot%202023-05-04%20at%2010-08-56%20Resevartion%20LaraRestaurant.png)